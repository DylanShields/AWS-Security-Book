
def register_ip_address(event, context):
    print('hello world!')
