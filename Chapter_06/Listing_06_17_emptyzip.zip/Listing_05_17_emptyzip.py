
def register_ip_address():
    pass
